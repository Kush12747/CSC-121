#include <string>
#include <iostream>
using namespace std;

class label
{
private:
	string fname;
	string lname;
	int zip;
public:
	label();//MUST 
	label(string, string, int);
	~label();
	//get functions Accessor function
	string getFname();
	string getLname();
	int getZip();
	//set functions Mutator function
	void setFname(string);
	void setLname(string);
	void setZip(int);
	//extra functions
	void print();
	void getInput();
	
};

